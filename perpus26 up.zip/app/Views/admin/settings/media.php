<?= $this->include('admin/settings/index') ?>


<script>
    const config = {
        controller: 'settings/media',
        dirUpload: 'upload/images/'
    }

    
</script>