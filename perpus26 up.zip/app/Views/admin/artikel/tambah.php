<h2>Tambah Artikel</h2>
<form method="post" action="/admin/artikel/simpan">
    <input type="text" name="judul" placeholder="Judul"><br>
    <textarea name="isi" placeholder="Isi artikel"></textarea><br>
    <button type="submit">Simpan</button>
</form>
