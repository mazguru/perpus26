
<footer class="bg-white border-t mt-auto border-gray-200 shadow-sm md:flex md:items-center md:justify-between md:p-6 dark:bg-gray-800 dark:border-gray-600">
    <p>© <?= date('Y') ?> Blog Perpustakaan. All rights reserved.</p>
  </footer>