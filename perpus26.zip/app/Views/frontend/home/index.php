<!-- Hero Section -->
<?= $this->include('frontend/home/hero') ?>



<!-- Berita Section -->
 <?= $this->include('frontend/home/berita') ?>


<?= $this->include('frontend/home/galery') ?>
<!-- Layanan Section -->
<?= $this->include('frontend/home/layanan') ?>


<!-- Kontak Section -->
 <?= $this->include('frontend/home/contact')?>

