<div x-data="mgrData(config)" x-init="loadData()">

    <?= $this->include('admin/posts/list') ?>

</div>
<script>
    const config = {
        controller: 'blog/posts',
        dirUpload: 'upload/image/',
        columns: [{
                key: 'post_title',
                label: 'Judul'
            },
            {
                key: 'post_author',
                label: 'Author'
            },
            {
                key: 'post_status',
                label: 'Status'
            },
            {
                key: 'category_name',
                label: 'Kategori'
            },
            {
                key: 'created_at',
                label: 'Tanggal Pembuatan'
            },
            {
                label: 'Aksi',
                orderable: false,
                key: null,
                priority: 2,
                render: (data, type, row) => {
                    const ds = row.date === null ? 'pointer-events-none opacity-25' : '';
                    return `
                        <button @click="editContent(${row.id})"
                        class="bg-cyan-600 hover:bg-cyan-700 focus:ring-4 focus:ring-cyan-200 text-white px-2 py-1 rounded ${ds}">
                            Edit
                        </button>
                    
                    `;
                }
            }
        ],
    }
</script>