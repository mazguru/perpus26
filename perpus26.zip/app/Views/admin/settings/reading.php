
<?= $this->include('admin/settings/index') ?>


<script>
    const config = {
        controller: 'settings/reading',
        dirUpload: 'upload/image/'
    }

    
</script>

