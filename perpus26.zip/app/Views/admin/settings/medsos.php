<?= $this->include('admin/settings/index') ?>


<script>
    const config = {
        controller: 'settings/medsos',
        dirUpload: 'upload/image/'
    }

    
</script>