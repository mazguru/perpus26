<?= $this->include('admin/settings/index') ?>


<script>
    const config = {
        controller: 'settings/general',
        dirUpload: 'assets/images/'
    }

    
</script>