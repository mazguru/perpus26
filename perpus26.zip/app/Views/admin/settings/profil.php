<?= $this->include('admin/settings/index') ?>


<script>
    const config = {
        controller: 'settings/profil',
        dirUpload: 'upload/images/'
    }

    
</script>