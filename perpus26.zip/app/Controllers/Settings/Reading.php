<?php
namespace App\Controllers\Settings;

use App\Controllers\AdminController;
use App\Models\SettingsModel;

class Reading extends AdminController
{
    protected $settingsModel;

    public function __construct()
    {
        $this->settingsModel = new SettingsModel();
    }

    public function getIndex()
    {
        $data = [
            'content'=>'admin/settings/reading',
            'title' => 'Pengaturan Penulisan',
        ];
        return view('layouts/master_admin', $data);
    }

    public function getList()
    {
        $settings = $this->settingsModel->getSettingGroupValues('reading');
        $results = [];
        foreach ($settings as $key => $value) {
            $description = $this->settingsModel->getSetting($key);
            $results[] = [
                'id' => $description['id'],
                'setting_variable' => $key,
                'setting_description' => $description['setting_description'],
                'setting_value' => $value,
                
            ];
        }
        $data = [
            'data' => $results
        ];
        return $this->response->setJSON($data);
    }
    public function postSave()
    {
        if (!$this->request->isAJAX()) {
            return $this->response->setJSON(['status' => 'error', 'message' => 'Request bukan AJAX.']);
        }

        $data = $this->request->getJSON(true);
        $id = $data['id'] ?? null;

        if (!$id || !$this->validate(['setting_value' => 'required'])) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => 'Periksa form kembali',
                'errors' => $this->validator->getErrors()
            ]);
        }

        $updated = $this->settingsModel->update($id, [
            'setting_value' => $data['setting_value'],
            'updated_by' => session('user_id')
        ]);

        return $this->response->setJSON([
            'status' => $updated ? 'success' : 'error',
            'message' => $updated ? 'Data Anda berhasil disimpan.' : 'Terjadi kesalahan dalam menyimpan data'
        ]);
    }

    public function postUpload()
    {
        if (!$this->request->isAJAX()) return;

        $id = (int)$this->request->getPost('id');
        $setting = $this->settingsModel->find($id);
        $oldFile = $setting['setting_value'] ?? '';

        $file = $this->request->getFile('file');
        if (!$file->isValid()) {
            return $this->response->setJSON([
                'status' => 'error',
                'message' => $file->getErrorString()
            ]);
        }

        $newName = $file->getRandomName();
        $file->move('assets/images/', $newName);

        if ($oldFile && is_file(FCPATH . 'assets/images/' . $oldFile)) {
            @unlink(FCPATH . 'assets/images/' . $oldFile);
        }

        $this->settingsModel->update($id, ['setting_value' => $newName]);

        if ($setting['setting_variable'] != 'headmaster_photo') {
            $this->imageResize(FCPATH . 'assets/images/', $newName, $setting['setting_variable']);
        }

        return $this->response->setJSON(['status' => 'success', 'message' => 'uploaded']);
    }

    private function imageResize($path, $fileName, $key)
    {
        $settings = [
            'logo_width' => session('logo_width') ?? 120,
            'logo_height' => session('logo_height') ?? 120,
            'favicon_width' => session('favicon_width') ?? 50,
            'favicon_height' => session('favicon_height') ?? 50,
            'header_width' => session('header_width') ?? 240,
			'header_height' => session('header_height') ?? 32
        ];

        $service = \Config\Services::image()
            ->withFile($path . $fileName)
            ->resize(
                (int)($settings[$key . '_width'] ?? 120),
                (int)($settings[$key . '_height'] ?? 120),
                true
            )
            ->save($path . $fileName);
    }
}
