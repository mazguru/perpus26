<?php

namespace App\Controllers\Publik;

use App\Controllers\PublicController;
use CodeIgniter\I18n\Time;

class Feed extends PublicController
{

    /**
     * Contoh feed XML generic (bukan RSS/Atom).
     * URL: /feed.xml  (lihat routes di bawah)
     */
    public function index()
    {
        helper(['url', 'Site', 'App']); // site => untuk strip_tags_truncate() jika Anda pakai

        $limit = (int) (session('post_rss_count') ?? 20);

        // Ganti dengan class model CI4 Anda
        $posts = get_latest_posts($limit);

        // Normalisasi data ke struktur array agar formatter XML rapi
        $items = [];
        foreach ($posts as $p) {
            $title   = $p['post_title']   ?? ($p['title'] ?? '');
            $post_type   = $p['post_type'];
            $slug    = $p['post_slug']    ?? ($p['slug'] ?? '');
            $content = $p['post_content'] ?? ($p['content'] ?? '');
            $created = $p['created_at']   ?? ($p['updated_at'] ?? Time::now('UTC')->toDateTimeString());
            $updated = $p['updated_at']   ?? $created;

            $items[] = [
                'id'         => (int)($p['id'] ?? 0),
                'title'      => $title,
                'slug'       => $slug,
                'url'        => base_url($post_type . '/' . $slug),
                'excerpt'    => strip_tags_truncate($content, 300),
                'created_at' => date(DATE_ATOM, strtotime($created)),
                'updated_at' => date(DATE_ATOM, strtotime($updated)),
            ];
        }

        $payload = [
            'site'  => [
                'title'        => __session('nama_perpus'),
                'link'         => rtrim(base_url(), '/'),
                'generated_at' => date(DATE_ATOM),
            ],
            // Agar elemen anak tidak semuanya “<item>0</item>…”, bungkus dengan nama elemen jelas:
            'items' => [
                'item' => $items, // CI4 formatter akan membuat <items><item>...</item></items>
            ],
        ];

        // Gunakan setXML() agar header Content-Type: application/xml otomatis
        // (Anda masih bisa menambah ETag/Cache-Control bila perlu)
        $xmlResponse = $this->response->setXML($payload);

        $etag = '"' . sha1($xmlResponse->getBody()) . '"';
        $xmlResponse
            ->setHeader('ETag', $etag)
            ->setCache(['max-age' => 300, 's-maxage' => 300]);

        if ($this->request->getHeaderLine('If-None-Match') === $etag) {
            return $xmlResponse->setStatusCode(304);
        }

        return $xmlResponse;
    }
}
