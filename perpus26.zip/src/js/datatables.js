import DataTable from 'datatables.net';


// Import DataTables Responsive
import 'datatables.net-responsive';

window.DataTable = DataTable;