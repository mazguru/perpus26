// Import Toastr dengan benar
import Notifier from './notifier';

window.Notifier = Notifier; // ✅ Pastikan toastr tersedia di global scope