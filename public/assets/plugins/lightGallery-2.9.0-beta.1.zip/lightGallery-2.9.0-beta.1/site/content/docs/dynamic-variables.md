---
title: 'Dynamic variables'
description: 'lightGallery dynamic variables.'
lead:
    'LightGallery can be instantiated and launched programmatically by setting
    dynamic option to true and populating dynamicEl option by passing array of
    objects representing the gallery elements. <a
    href="../../demos/dynamic-mode/">more info.</a>'
date: 2020-10-06T08:48:57+00:00
draft: false
images: []
menu:
    docs:
        parent: 'API Docs'
weight: 5
toc: true
---

### Available options

{{< attributes interface="GalleryItem">}}
