function showLoading() {
    document.getElementById('isLoading').style.display = 'flex';
}

function hideLoading() {
    setTimeout(() => {
        document.getElementById('isLoading').style.display = 'none';
    }, 100);
}
function settingsApp(config) {
    return {
        baseUrl: _BASEURL + config.dirUpload,
        data: '',
        isModalOpen: false,
        editIndex: null,
        editItem: {
            setting_description: '',
            setting_variable: '',
            setting_value: ''
        },
        selectedFile: null,
        errorData: '',
        async fetchData(url, method = 'GET', body = null) {
            try {
                const headers = {
                    'X-Requested-With': 'XMLHttpRequest'
                };
                const isFormData = body instanceof FormData;

                if (!isFormData) headers['Content-Type'] = 'application/json';

                const response = await fetch(url, {
                    method,
                    headers,
                    body: body ? (isFormData ? body : JSON.stringify(body)) : null
                });

                // Handle status error
                if (!response.ok) {
                    const errorText = await response.text();
                    console.error('HTTP Error', response.status, errorText);
                    return null; // fetchData akan return null => tangani di pemanggil
                }

                return await response.json();
            } catch (error) {
                console.error('Fetch error:', error);
                return null;
            }
        },
        async loadSettings() {
            const response = await this.fetchData(_BASEURL + `${config.controller}/list`);
            if (response) {
                this.data = response.data;
            } else {
                Notifier.show('Error', 'Gagal memuat data.', 'error');
            }
        },
        getFieldType(variable) {
            if (this.isDateField(variable)) return "date";
            if (this.isNumberField(variable)) return "number";
            return "text";
        },
        isDateField(variable) {
            return ["site_maintenance_end_date", "decree_operating_permit_date", "date_of_birth"].includes(variable);
        },
        isNumberField(variable) {
            return ["age", "price", "quantity"].includes(variable);
        },
        isUploadField(settingVariable) {
            return ['favicon', 'logo', 'header'].includes(settingVariable);
        },
        isTextArea(settingVariable) {
            return ['meta_description', 'meta_keywords'].includes(settingVariable);
        },
        isOptions(settingVariable) {
            return ['site_maintenance', 'cooming_soon', 'timezone', 'recaptcha_status', 'site_cache', 'default_post_status', 'default_post_visibility', 'default_post_discussion', 'comment_order', 'comment_registration', 'comment_moderation'].includes(settingVariable);
        },
        optionSources: {
            default_post_status: { publish: "Diterbitkan", draft: "Konsep" },
            default_post_visibility: { public: "Publik", private: "Private" },
            default_post_discussion: { open: "Dibuka", close: "Ditutup" },
            comment_order: { asc: "Ascending", desc: "Descending" },
            site_maintenance: { true: 'Ya', false: 'Tidak' },
            comment_moderation: { true: 'Ya', false: 'Tidak' },
            comment_registration: { true: 'Ya', false: 'Tidak' },
            site_cache: { true: 'Ya', false: 'Tidak' },
            timezone: {
                'Asia/Jakarta': 'Asia/Jakarta',
                'Asia/Makassar': 'Asia/Makassar',
                'Asia/Jayapura': 'Asia/Jayapura'
            },
            recaptcha_status: {
                'enable': 'Enable',
                'disable': 'Disable'
            }
        },
        getOptions(key) {
            return this.optionSources[key] || {};
        },
        openEditModal(index) {
            this.editIndex = index;
            this.editItem = {
                ...this.data[index]
            };
            this.isModalOpen = true;
        },
        closeModal() {
            this.isModalOpen = false;
            this.editItem = {
                setting_description: '',
                setting_variable: '',
                setting_value: ''
            };
            this.errorData = '';
            this.selectedFile = null;
        },
        async saveEdit() {

            if (this.isUploadField(this.editItem.setting_variable) && !this.selectedFile) {
                Notifier.show('Error', 'File harus diunggah untuk pengaturan ini.', 'error');
                return;
            }
            this.updateSettingValue();
            if (this.selectedFile) await this.uploadFile();
        },
        async updateSettingValue() {
            const url = _BASEURL + `${config.controller}/save`;
            const response = await this.fetchData(url, 'POST', this.editItem);
            console.log(response);
            if (response.status == 'success') {
                Notifier.show('Berhasil', response.message, response.status);
                this.loadSettings();
                this.closeModal();
            } else {
                this.errorData = response.errors;
                Notifier.show('Gagal', response.message, response.status);
            }

        },
        handleFileChange(event) {
            const file = event.target.files[0];
            const allowedExtensions = ['jpg', 'jpeg', 'png', 'gif'];
            if (file && allowedExtensions.includes(file.name.split('.').pop().toLowerCase())) {
                this.selectedFile = file; // Simpan file jika valid
            } else {
                this.selectedFile = null; // Reset jika file tidak valid
                Notifier.show('Error', 'File harus berupa JPG, JPEG, PNG, atau GIF.', 'error');
            }
        },
        async uploadFile() {
            const formData = new FormData();
            formData.append('file', this.selectedFile);
            formData.append('setting_variable', this.editItem.setting_variable);
            formData.append('id', this.editItem.id);

            const response = await this.fetchData(_BASEURL + `${config.controller}/upload`, 'POST', formData);
            if (response && response.status) {
                Notifier.show('Berhasil', response.message, response.status);
                this.loadSettings();
                this.closeModal();
            } else {
                Notifier.show('Gagal', response.message, response.status);
            }
        },

    };
}

function DM(config) {
    return {

        modalType: 'create',
        tableData: [],
        form: {},
        errors: {},
        dataTableInstance: null,
        showModal: false,
        //option
        optionsData: [],

        selectedId: [],

        deleteUrl: _BASEURL + `${config.controller}/delete`,
        editUrl: _BASEURL + `${config.controller}/edit`,
        createUrl: _BASEURL + `${config.controller}/create`,
        restoreUrl: _BASEURL + `${config.controller}/restore`,
        optionsUrl: _BASEURL + `${config.controller}/options`,
        deletePermanentlyUrl: _BASEURL + `${config.controller}/delete_permanently`,

        apiUrl: _BASEURL + `${config.controller}/list/`,

        async fetchData(url, method = 'GET', body = null) {
            showLoading();
            try {
                const response = await fetch(url, {
                    method,
                    headers: { 'Content-Type': 'application/json', 'X-Requested-With': 'XMLHttpRequest', },
                    body: body ? JSON.stringify(body) : null,
                });

                if (!response.ok) throw new Error('Network error');

                return await response.json();
            } catch (error) {
                console.error('Fetch error:', error);
                return null;
            } finally {
                hideLoading();
            }
        },

        async loadData() {
            const response = await this.fetchData(this.apiUrl);
            console.log(response);
            if (response && response.alldata) {
                this.tableData = response.alldata || [];
                this.renderDataTable();
            }
        },

        async loadOptions() {
            const response = await this.fetchData(this.optionsUrl);
            console.log('options', response);
            if (response) {
                this.optionsData = response;
            }
        },

        renderDataTable() {
            const table = document.querySelector('#table-data');

            if (this.dataTableInstance) {
                this.dataTableInstance.clear().rows.add(this.tableData).draw();
            } else {
                this.dataTableInstance = new DataTable(table, {
                    data: this.tableData,
                    columns: [
                        {
                            title: 'No',
                            data: 'id',
                            render: (_, __, row, meta) => meta.row + 1
                        },
                        {
                            data: 'id',
                            orderable: false,
                            title: `<input type="checkbox" @click="selectAll($event)" />`,
                            responsivePriority: 1,
                            render: (data, type, row) =>
                                `<input :value="${row.id}" x-model="selectedId" type="checkbox" />`,
                        },
                        ...config.columns.map(col => ({
                            data: col.key,
                            title: col.label,
                            render: col.render || ((data) => data)
                        })),
                        { // Tambahkan kolom aksi secara otomatis
                            data: null,
                            title: 'Aksi',
                            orderable: false,
                            responsivePriority: 3,
                            render: (data, type, row) => {
                                return `
                                <div x-data="{ isOpen: false }" class="relative inline-block text-left ">
                                        <button @click.prevent="isOpen = !isOpen" class="flex items-center gap-1.5 rounded-md px-3 py-1.5 text-sm bg-blue-200 hover:text-primary dark:bg-meta-4 dark:shadow-none shadow-md hover:bg-blue-400 transition">
                                            Action
                                            <svg class="fill-current" width="16" height="16" viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
                                                <path d="M8.00039 11.4C7.85039 11.4 7.72539 11.35 7.60039 11.25L1.85039 5.60005C1.62539 5.37505 1.62539 5.02505 1.85039 4.80005C2.07539 4.57505 2.42539 4.57505 2.65039 4.80005L8.00039 10.025L13.3504 4.75005C13.5754 4.52505 13.9254 4.52505 14.1504 4.75005C14.3754 4.97505 14.3754 5.32505 14.1504 5.55005L8.40039 11.2C8.27539 11.325 8.15039 11.4 8.00039 11.4Z" fill=""></path>
                                            </svg>
                                        </button>
                                        <div
                                            x-show="isOpen"
                                            @click.outside="isOpen = false"
                                            class="absolute right-0 mt-1 w-32 bg-white shadow-lg rounded-md border dark:bg-gray-800 z-50"
                                            style="display: none;">
                                            
                                    ${row.is_deleted == 1
                                        ? `<button
                                                class="w-full px-4 py-2 text-left text-black dark:text-white hover:bg-gray-100 flex items-center"
                                                @click="confirmRestore(${row.id})">
                                                <i class="bi mr-2 bi-database-up"></i>
                                                <span>Restore</span>
                                            </button>`
                                        : `<button
                                                class="w-full px-4 py-2 text-left hover:bg-gray-100 flex items-center"
                                                @click="openModal('edit', ${row.id})">
                                                <i class="bi mr-2 bi-pencil-square"></i>
                                                <span>Edit</span>
                                            </button>
                                            <button
                                                class="w-full px-4 py-2 text-left text-sm hover:bg-gray-100 flex items-center"
                                                @click="confirmDelete(${row.id})">
                                                <i class="bi bi-trash3-fill mr-2"></i>
                                                <span>Delete</span>
                                            </button>`
                                    }
                                            
                                        </div>
                                    </div>
                                `;
                            }
                        }
                    ],
                    pageLength: 25,
                    language: {
                        search: '_INPUT_',
                        searchPlaceholder: 'Cari...'
                    },
                    responsive: true,
                    dom: '<"md:flex justify-between mb-2"<"search-box mb-2"f><"info-box"l>>t<"md:flex justify-between mt-2"<"info-box mb-2"i><"pagination"p>>',
                    rowCallback: function (row, data) {
                        if (data.is_deleted == 'true') {
                            row.classList.add("text-red-700"); // Warna merah untuk baris
                            row.style.textDecoration = "line-through";
                        }
                    },
                });
            }
        },


        openModal(type, id = null) {
            this.modalType = type;
            this.showModal = true;

            if (type === 'edit' && id) {
                // Konversi id ke Number jika perlu
                const parsedId = Number(id);
                const dataModal = this.tableData.find(item => Number(item.id) === parsedId);

                if (dataModal) {
                    this.form = { ...dataModal };
                } else {
                    Notifier.show('Error', `Data dengan ID ${id} tidak ditemukan.`, 'error');
                }
            } else {
                this.resetForm();
            }
        },


        closeModal() {
            this.showModal = false;
            this.resetForm();
        },

        resetForm() {
            this.form = {};
        },

        async submitForm() {
            const url = this.modalType === 'create' ? this.createUrl : `${this.editUrl}/${this.form.id}`;
            const method = this.modalType === 'create' ? 'POST' : 'PUT';

            const response = await this.fetchData(url, method, this.form);
            if (response && response.status === 'success') {
                Notifier.show('Berhasil!', response.message, 'success');
                this.loadData();
                this.closeModal();
            } else {
                this.errors = response.errors ? response.errors : [];
                Notifier.show('Gagal!', response ? response.message : 'Terjadi kesalahan.', 'error');
            }
        },
        selectAll(event) {
            const checkboxes = document.querySelectorAll('tbody input[type="checkbox"]');
            this.selectedId = event.target.checked ?
                Array.from(checkboxes).map((checkbox) => checkbox.value) : [];
            checkboxes.forEach((checkbox) => (checkbox.checked = event.target.checked));
        },
        confirmDelete(id) {
            const confirmDelete = confirm('Apakah Anda yakin ingin menghapus data ini?');
            if (!confirmDelete) return;
            this.deleteData([id]);
        },

        confirmDeleteMultiple() {
            const confirmDelete = confirm('Apakah Anda yakin ingin menghapus data ini?');
            if (!confirmDelete) return;
            this.deleteData(this.selectedId);
        },
        async deleteData(ids) {

            const response = await this.fetchData(_BASEURL + `${config.controller}/delete`, 'POST', {
                id: ids
            });

            if (response && response.status === 'success') {
                Notifier.show('Berhasil!', response.message, 'success');
                this.loadData();
                this.selectedId = [];
                document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
                    checkbox.checked = false;
                });
            } else {
                Notifier.show('Gagal!', response ? response.message : 'Terjadi kesalahan.', 'error');
            }
        },

        confirmDeletepermanent(id) {
            const confirmDelete = confirm('Apakah Anda yakin ingin menghapus data ini?');
            if (!confirmDelete) return;
            this.deleteDataPermanent([id]);
        },
        async deleteDataPermanent(ids) {
            const response = await this.fetchData(_BASEURL + `${config.controller}/deletepermanent`, 'POST', {
                id: ids
            });

            if (response && response.status === 'success') {
                Notifier.show('Berhasil!', response.message, 'success');
                this.loadData();
                this.selectedId = [];
                document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
                    checkbox.checked = false;
                });
            } else {
                Notifier.show('Gagal!', response ? response.message : 'Terjadi kesalahan.', 'error');
            }
        },
        confirmRestore(id) {
            const confirmDelete = confirm('Apakah Anda yakin ingin mengembalikan data ini?');
            if (!confirmDelete) return;
            this.restoreData([id]);
        },
        confirmRestoreMultiple() {
            const confirmDelete = confirm('Apakah Anda yakin ingin mengembalikan data ini?');
            if (!confirmDelete) return;
            this.restoreData(this.selectedId);
        },
        async restoreData(ids) {
            const response = await this.fetchData(_BASEURL + `${config.controller}/restore`, 'POST', {
                id: ids
            });
            if (response && response.status === 'success') {
                Notifier.show('Berhasil!', response.message, 'success');
                this.loadData();
                this.selectedId = [];
                document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
                    checkbox.checked = false;
                });
            } else {
                Notifier.show('Gagal!', response ? response.message : 'Terjadi kesalahan.', 'error');
            }
        },

    };
}

function mgrData(config) {
    return {
        showModal: false,
        modalTitle: 'Tambah Album',
        modalType: 'create',
        form: {},
        tableData: [],
        previewFile: null,
        dataTableInstance: null,
        errorData: '',
        selectedId: [],

        errors:{},


        deleteUrl: _BASEURL + `${config.controller}/delete`,
        editUrl: _BASEURL + `${config.controller}/edit`,
        createUrl: _BASEURL + `${config.controller}/create`,
        restoreUrl: _BASEURL + `${config.controller}/restore`,

        async fetchData(url, method = 'GET', body = null) {
            try {
                const headers = {
                    'X-Requested-With': 'XMLHttpRequest'
                };
                const isFormData = body instanceof FormData;

                if (!isFormData) headers['Content-Type'] = 'application/json';

                const response = await fetch(url, {
                    method,
                    headers,
                    body: body ? (isFormData ? body : JSON.stringify(body)) : null
                });

                // Handle status error
                if (!response.ok) {
                    const errorText = await response.text();
                    console.error('HTTP Error', response.status, errorText);
                    return null; // fetchData akan return null => tangani di pemanggil
                }

                return await response.json();
            } catch (error) {
                console.error('Fetch error:', error);
                return null;
            }
        },
        async loadData() {
            const response = await this.fetchData(_BASEURL + `${config.controller}/list`);
            console.log(response);
            if (response) {
                this.tableData = response.alldata;
                this.renderDataTable();
            } else {
                Notifier.show('Error', 'Gagal memuat data.', 'error');
            }
        },

        renderDataTable() {
            const table = document.querySelector('#table-data');
            if (this.dataTableInstance) {
                this.dataTableInstance.clear().rows.add(this.tableData).draw();
            } else {
                this.dataTableInstance = new DataTable(table, {
                    data: this.tableData,
                    columns: [{
                        title: 'No',
                        data: 'id',
                        render: (_, __, row, meta) => meta.row + 1
                    },
                    {
                        data: 'id',
                        orderable: false,
                        title: `<input type="checkbox" @click="selectAll($event)" />`,
                        responsivePriority: 1,
                        render: (data, type, row) =>
                            `<input :value="${row.id}" x-model="selectedId" type="checkbox" />`,
                    },
                    ...config.columns.map(col => ({
                        data: col.key,
                        title: col.label,
                        orderable: col.orderable ?? true,
                        responsivePriority: col.priority ?? 10,
                        render: col.render || ((data) => data)
                    })),
                    ],
                    pageLength: 25,
                    language: {
                        search: '_INPUT_',
                        searchPlaceholder: 'Cari...'
                    },
                    responsive: true,
                    dom: '<"md:flex justify-between mb-2"<"search-box mb-2"f><"info-box"l>>t<"md:flex justify-between mt-2"<"info-box mb-2"i><"pagination"p>>',
                    rowCallback: function (row, data) {
                        if (data.is_deleted == 'true') {
                            row.classList.add("text-red-700"); // Warna merah untuk baris
                            row.style.textDecoration = "line-through";
                        }
                    },
                });
            }
        },
        openModal(type, id = null) {
            this.modalType = type;
            this.showModal = true;
        },

        closeModal() {
            this.showModal = false;
            this.resetForm();
        },

        resetForm() {
            this.form = {};
        },

        generateSlug(str) {
            return str
                .toLowerCase()
                .replace(/[^a-z0-9\s-]/g, '')
                .replace(/\s+/g, '-')
                .replace(/-+/g, '-');
        },

        handleCoverUpload(event) {
            const file = event.target.files[0];
            if (file) {
                this.form.image_cover = file;
                this.previewFile = URL.createObjectURL(file);
            }
        },

        editData(id) {
            const item = this.tableData.find(m => m.id == id); // gunakan == agar type fleksibel

            if (item) {
                this.form = {
                    ...item
                };
                this.previewFile = item.image_cover ?
                    _BASEURL + `upload/image/${item.image_cover}` :
                    null;

                this.modalType = 'edit';
                this.showModal = true;
            } else {
                Notifier.show('Error', 'Data tidak ditemukan', 'error');
            }
        },

        confirmDelete(id) {
            const confirmDelete = confirm('Apakah Anda yakin ingin menghapus data ini?');
            if (!confirmDelete) return;
            this.deleteData([id]);
        },

        confirmDeleteMultiple() {
            const confirmDelete = confirm('Apakah Anda yakin ingin menghapus data ini?');
            if (!confirmDelete) return;
            this.deleteData(this.selectedId);
        },
        async deleteData(ids) {

            const response = await this.fetchData(_BASEURL + `${config.controller}/delete`, 'POST', {
                id: ids
            });

            if (response && response.status === 'success') {
                Notifier.show('Berhasil!', response.message, 'success');
                this.loadData();
                this.selectedId = [];
                document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
                    checkbox.checked = false;
                });
            } else {
                Notifier.show('Gagal!', response ? response.message : 'Terjadi kesalahan.', 'error');
            }
        },

        confirmDeletepermanent() {
            const confirmDelete = confirm('Apakah Anda yakin ingin menghapus data ini?');
            if (!confirmDelete) return;
            this.deleteDataPermanent(this.selectedId);
        },
        async deleteDataPermanent(ids) {
            const response = await this.fetchData(_BASEURL + `${config.controller}/deletepermanent`, 'POST', {
                id: ids
            });
            console.log(response);
            if (response && response.status === 'success') {
                Notifier.show('Berhasil!', response.message, 'success');
                this.loadData();
                this.selectedId = [];
                document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
                    checkbox.checked = false;
                });
            } else {
                Notifier.show('Gagal!', response ? response.message : 'Terjadi kesalahan.', 'error');
            }
        },
        confirmRestore(id) {
            const confirmDelete = confirm('Apakah Anda yakin ingin mengembalikan data ini?');
            if (!confirmDelete) return;
            this.restoreData([id]);
        },
        confirmRestoreMultiple() {
            const confirmDelete = confirm('Apakah Anda yakin ingin mengembalikan data ini?');
            if (!confirmDelete) return;
            this.restoreData(this.selectedId);
        },
        async restoreData(ids) {
            const response = await this.fetchData(_BASEURL + `${config.controller}/restore`, 'POST', {
                id: ids
            });
            if (response && response.status === 'success') {
                Notifier.show('Berhasil!', response.message, 'success');
                this.loadData();
                this.selectedId = [];
                document.querySelectorAll('input[type="checkbox"]').forEach(checkbox => {
                    checkbox.checked = false;
                });
            } else {
                Notifier.show('Gagal!', response ? response.message : 'Terjadi kesalahan.', 'error');
            }
        },

        selectAll(event) {
            const checkboxes = document.querySelectorAll('tbody input[type="checkbox"]');
            this.selectedId = event.target.checked ?
                Array.from(checkboxes).map((checkbox) => checkbox.value) : [];
            checkboxes.forEach((checkbox) => (checkbox.checked = event.target.checked));
        },

        async submitForm() {
            let url = this.form.id ?
                _BASEURL + `${config.controller}/update/${this.form.id}` :
                _BASEURL + `${config.controller}/create`;

            const formData = new FormData();
            for (const key in this.form) {
                formData.append(key, this.form[key]);
            }

            // Pastikan elemen file dimasukkan (gunakan ref atau cara lain)
            const imageInput = document.querySelector('input[name="image_cover"]');
            if (imageInput && imageInput.files.length > 0) {
                formData.append('image_cover', imageInput.files[0]);
            }

            const res = await this.fetchData(url, 'POST', formData);
            if (res && res.status === 'success') {
                this.showModal = false;
                Notifier.show('Berhasil', res.message, 'success');
                this.loadData();
            } else {
                this.errorData = res?.errors || ''
                Notifier.show('Error', res?.message || 'Gagal menyimpan data', 'error');
            }
        },

        goLink(url) {
            window.location.href = url;
        },
        addContent() {
            window.location.href = this.createUrl;
        },
        editContent(id) {
            window.location.href = this.editUrl + '/'+ id;
        }

    };
}

function postingan(config) {
    return {
        baseUrl: _BASEURL + config.dirUpload,
        tableData: '',
        isModalOpen: false,
        editIndex: null,
        editItem: {
            setting_description: '',
            setting_variable: '',
            setting_value: ''
        },
        selectedFile: null,
        errorData: '',
        async fetchData(url, method = 'GET', body = null) {
            try {
                const headers = {
                    'X-Requested-With': 'XMLHttpRequest'
                };
                const isFormData = body instanceof FormData;

                if (!isFormData) headers['Content-Type'] = 'application/json';

                const response = await fetch(url, {
                    method,
                    headers,
                    body: body ? (isFormData ? body : JSON.stringify(body)) : null
                });

                // Handle status error
                if (!response.ok) {
                    const errorText = await response.text();
                    console.error('HTTP Error', response.status, errorText);
                    return null; // fetchData akan return null => tangani di pemanggil
                }

                return await response.json();
            } catch (error) {
                console.error('Fetch error:', error);
                return null;
            }
        },
        async loadPosts() {
            const response = await this.fetchData(_BASEURL + `${config.controller}/list`);
            console.log(response);
            if (response) {
                this.tableData = response;
                this.renderDataTable();
            } else {
                Notifier.show('Error', 'Gagal memuat data.', 'error');
            }
        },

        renderDataTable() {
            const table = document.querySelector('#table-posts');
            if (this.dataTableInstance) {
                this.dataTableInstance.clear().rows.add(this.tableData).draw();
            } else {
                this.dataTableInstance = new DataTable(table, {
                    data: this.tableData,
                    columns: [{
                        title: 'No',
                        data: 'id',
                        responsivePriority: 1,
                        render: (_, __, row, meta) => meta.row + 1
                    },
                    ...config.columns.map(col => ({
                        data: col.key,
                        title: col.label,
                        orderable: col.orderable ?? true,
                        responsivePriority: col.priority ?? 10,
                        render: col.render || ((data) => data)
                    })),
                    ],
                    pageLength: 25,
                    language: {
                        search: '_INPUT_',
                        searchPlaceholder: 'Cari...'
                    },
                    responsive: true,
                    dom: '<"md:flex justify-between mb-2"<"search-box mb-2"f><"info-box"l>>t<"md:flex justify-between mt-2"<"info-box mb-2"i><"pagination"p>>',
                    rowCallback: function (row, data) {
                        if (data.is_deleted == 'true') {
                            row.classList.add("text-red-700"); // Warna merah untuk baris
                            row.style.textDecoration = "line-through";
                        }
                    },
                });
            }
        },
        editPost(id) {
            window.location.href = _BASEURL + config.controller + '/create/' + id
        },
        addPost() {
            window.location.href = _BASEURL + config.controller + '/create'
        }

    };
}